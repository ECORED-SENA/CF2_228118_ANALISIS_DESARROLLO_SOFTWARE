function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5tbOebH0TiL":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

